<template>
    <p >Lista de Recetas</p>
        <br>
         <table class="min-w-full divide-y divide-gray-200 border">
            <thead>
            <tr>
                <th class="px-6 py-3 bg-gray-50 text-left">
                    <span class="text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Id</span>
                </th>
                <th class="px-6 py-3 bg-gray-50 text-left">
                    <span class="text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Titulo</span>
                </th>
            </tr>
            </thead>

            <tbody class="bg-white divide-y divide-gray-200 divide-solid">

                <tr v-for="r in records" :key="r.id" class="bg-white">
                    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 text-gray-900">
                        {{r.id}}
                    </td>
                    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 text-gray-900">
                        {{r.name}}
                    </td>
                </tr>

            </tbody>
        </table>
</template>

<script>
import { ref, onMounted } from 'vue';
export default {
  setup() {
    const records= ref([])

    onMounted(() => {
        axios.get('api/recipes')
        .then(response => {
            records.value= response.data.data;
            console.log(records.value)
    })
        })

    return {
        records
        };
  },
};
</script>

<style>

</style>
