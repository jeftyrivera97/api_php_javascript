<template>
   <p>Historial de Ingredientes Comprados:</p>
        <br>
        <table class="min-w-full divide-y divide-gray-200 border">
            <thead>
            <tr>
                <th class="px-6 py-3 bg-gray-50 text-left">
                    <span class="text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Id</span>
                </th>
                <th class="px-6 py-3 bg-gray-50 text-left">
                    <span class="text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Ingrediente</span>
                </th>
                    <th class="px-6 py-3 bg-gray-50 text-left">
                    <span class="text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Cantidad Comprada</span>
                </th>
                <th class="px-6 py-3 bg-gray-50 text-left">
                    <span class="text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Fecha de Compra</span>
                </th>
            </tr>
            </thead>

            <tbody class="bg-white divide-y divide-gray-200 divide-solid">

                <tr v-for="c in records" :key="c.id" class="bg-white">
                    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 text-gray-900">
                        {{c.id}}
                    </td>
                    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 text-gray-900">
                        {{c.ingredient.name}}
                    </td>
                        <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 text-gray-900">
                        {{c.quantity}}
                    </td>
                        <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 text-gray-900">
                        {{c.created_at}}
                    </td>
                </tr>

            </tbody>
        </table>
</template>

<script>
import { ref, onMounted } from 'vue';
export default {
  setup() {
    const records= ref([])

    onMounted(() => {
        axios.get('api/mercados')
        .then(response => {
            records.value= response.data.data;
            console.log(records.value)
    })
        })

    return {
        records
        };
  },
};
</script>

<style>

</style>
